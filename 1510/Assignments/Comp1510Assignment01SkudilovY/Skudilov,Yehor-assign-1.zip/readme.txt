Yehor Skudilov, A01439865, A, Jan. 31 2025

This assignment is 100% complete.


------------------------
Question one (Change) status:

[Complete]

------------------------
Question two (Sqrt) status:

[Complete]

------------------------
Question three (Reverse) status:

[Complete]

------------------------
Question four (Pack) status:

[Complete]
